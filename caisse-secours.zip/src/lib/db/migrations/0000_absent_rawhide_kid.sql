CREATE TABLE `clients` (
	`id` text PRIMARY KEY NOT NULL,
	`matricule` text NOT NULL,
	`nom` text NOT NULL,
	`telephone` text NOT NULL,
	`solde` real DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `clients_matricule_unique` ON `clients` (`matricule`);--> statement-breakpoint
CREATE TABLE `commission_config` (
	`id` text PRIMARY KEY NOT NULL,
	`montant_min` real NOT NULL,
	`montant_max` real,
	`taux` real NOT NULL,
	`ordre` integer NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `commissions` (
	`id` text PRIMARY KEY NOT NULL,
	`client_id` text NOT NULL,
	`montant_total` real NOT NULL,
	`commission` real NOT NULL,
	`label` text NOT NULL,
	`type` text NOT NULL,
	`mois_annee` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` text PRIMARY KEY NOT NULL,
	`client_id` text NOT NULL,
	`type` text NOT NULL,
	`montant` real NOT NULL,
	`description` text,
	`source_destination` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`) ON UPDATE no action ON DELETE cascade
);
