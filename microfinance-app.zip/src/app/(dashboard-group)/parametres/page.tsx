'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Settings, 
  DollarSign, 
  Users, 
  Monitor, 
  Shield, 
  Save, 
  RotateCcw,
  AlertTriangle,
  CheckCircle
} from 'lucide-react'
import { toast } from 'sonner'

interface ConfigValue {
  value: any
  description: string
  type: string
  updatedAt: string
  updatedBy: string
}

interface ConfigData {
  transactions: Record<string, ConfigValue>
  clients: Record<string, ConfigValue>
  system: Record<string, ConfigValue>
  security: Record<string, ConfigValue>
}

export default function ParametresPage() {
  const [config, setConfig] = useState<ConfigData>({
    transactions: {},
    clients: {},
    system: {},
    security: {}
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [changes, setChanges] = useState<Record<string, any>>({})

  // Charger la configuration
  useEffect(() => {
    loadConfiguration()
  }, [])

  const loadConfiguration = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/config')
      if (response.ok) {
        const data = await response.json()
        setConfig(data)
      } else {
        toast.error('Erreur lors du chargement de la configuration')
      }
    } catch (error) {
      toast.error('Erreur de connexion')
    } finally {
      setLoading(false)
    }
  }

  const handleValueChange = (category: string, key: string, value: any) => {
    const changeKey = `${category}.${key}`
    setChanges(prev => ({
      ...prev,
      [changeKey]: { category, key, value }
    }))

    // Mettre à jour l'affichage local
    setConfig(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof ConfigData],
        [key]: {
          ...prev[category as keyof ConfigData][key],
          value: value
        }
      }
    }))
  }

  const handleSaveChanges = async () => {
    if (Object.keys(changes).length === 0) {
      toast.info('Aucune modification à sauvegarder')
      return
    }

    setSaving(true)
    let successCount = 0
    let errorCount = 0

    for (const change of Object.values(changes)) {
      try {
        const response = await fetch('/api/config', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(change)
        })

        if (response.ok) {
          successCount++
        } else {
          errorCount++
        }
      } catch (error) {
        errorCount++
      }
    }

    setSaving(false)
    setChanges({})

    if (errorCount === 0) {
      toast.success(`${successCount} paramètre(s) sauvegardé(s) avec succès`)
    } else {
      toast.error(`${errorCount} erreur(s) lors de la sauvegarde`)
    }

    // Recharger la configuration
    await loadConfiguration()
  }

  const handleResetCategory = async (category: string) => {
    if (!confirm(`Êtes-vous sûr de vouloir réinitialiser tous les paramètres de la catégorie "${category}" ?`)) {
      return
    }

    try {
      const response = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reset', category })
      })

      if (response.ok) {
        toast.success(`Paramètres de "${category}" réinitialisés`)
        await loadConfiguration()
        setChanges({}) // Effacer les changements en cours
      } else {
        toast.error('Erreur lors de la réinitialisation')
      }
    } catch (error) {
      toast.error('Erreur de connexion')
    }
  }

  const renderInput = (category: string, key: string, configValue: ConfigValue) => {
    const { value, type, description } = configValue
    const currentValue = changes[`${category}.${key}`]?.value ?? value

    switch (type) {
      case 'boolean':
        return (
          <div className="flex items-center space-x-2">
            <Switch
              checked={currentValue}
              onCheckedChange={(checked) => handleValueChange(category, key, checked)}
            />
            <Label>{currentValue ? 'Activé' : 'Désactivé'}</Label>
          </div>
        )
      
      case 'number':
        return (
          <Input
            type="number"
            value={currentValue}
            onChange={(e) => handleValueChange(category, key, Number(e.target.value))}
            className="max-w-xs"
          />
        )
      
      default:
        return (
          <Input
            type="text"
            value={currentValue}
            onChange={(e) => handleValueChange(category, key, e.target.value)}
            className="max-w-xs"
          />
        )
    }
  }

  const renderCategorySection = (category: string, icon: any, title: string, description: string) => {
    const categoryConfig = config[category as keyof ConfigData] || {}
    const Icon = icon

    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon className="h-5 w-5 text-blue-600" />
            <div>
              <CardTitle>{title}</CardTitle>
              <CardDescription>{description}</CardDescription>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleResetCategory(category)}
            className="text-red-600 hover:text-red-700"
          >
            <RotateCcw className="h-4 w-4 mr-1" />
            Réinitialiser
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          {Object.entries(categoryConfig).map(([key, configValue]) => (
            <div key={key} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-sm font-medium">{configValue.description}</Label>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" className="text-xs">
                      {configValue.type}
                    </Badge>
                    <span className="text-xs text-gray-500">
                      Modifié par {configValue.updatedBy}
                    </span>
                  </div>
                </div>
                {changes[`${category}.${key}`] && (
                  <Badge variant="secondary" className="text-xs">
                    <AlertTriangle className="h-3 w-3 mr-1" />
                    Modifié
                  </Badge>
                )}
              </div>
              {renderInput(category, key, configValue)}
              <Separator className="my-4" />
            </div>
          ))}
        </CardContent>
      </Card>
    )
  }

  if (loading) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </div>
    )
  }

  const hasChanges = Object.keys(changes).length > 0

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* En-tête */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Settings className="h-6 w-6 text-blue-600" />
          <div>
            <h1 className="text-2xl font-bold">Paramètres</h1>
            <p className="text-gray-600">Configuration des règles métier et paramètres système</p>
          </div>
        </div>
        
        {hasChanges && (
          <div className="flex items-center space-x-2">
            <Badge variant="secondary" className="animate-pulse">
              <AlertTriangle className="h-3 w-3 mr-1" />
              {Object.keys(changes).length} modification(s) en attente
            </Badge>
            <Button 
              onClick={handleSaveChanges} 
              disabled={saving}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {saving ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Sauvegarder
            </Button>
          </div>
        )}
      </div>

      {/* Tabs verticaux */}
      <Tabs defaultValue="transactions" className="flex space-x-6">
        <TabsList className="flex flex-col h-fit w-64 space-y-1">
          <TabsTrigger value="transactions" className="w-full justify-start">
            <DollarSign className="h-4 w-4 mr-2" />
            Transactions
          </TabsTrigger>
          <TabsTrigger value="clients" className="w-full justify-start">
            <Users className="h-4 w-4 mr-2" />
            Clients
          </TabsTrigger>
          <TabsTrigger value="system" className="w-full justify-start">
            <Monitor className="h-4 w-4 mr-2" />
            Système
          </TabsTrigger>
          <TabsTrigger value="security" className="w-full justify-start">
            <Shield className="h-4 w-4 mr-2" />
            Sécurité
          </TabsTrigger>
        </TabsList>

        <div className="flex-1">
          <TabsContent value="transactions">
            {renderCategorySection(
              'transactions', 
              DollarSign, 
              'Paramètres des Transactions',
              'Configuration des montants minimum, maximum et règles de validation'
            )}
          </TabsContent>

          <TabsContent value="clients">
            {renderCategorySection(
              'clients', 
              Users, 
              'Paramètres des Clients',
              'Configuration de la validation des données clients et formats'
            )}
          </TabsContent>

          <TabsContent value="system">
            {renderCategorySection(
              'system', 
              Monitor, 
              'Paramètres Système',
              'Configuration générale de l\'application et pagination'
            )}
          </TabsContent>

          <TabsContent value="security">
            {renderCategorySection(
              'security', 
              Shield, 
              'Paramètres de Sécurité',
              'Configuration de l\'audit, sessions et tentatives de connexion'
            )}
          </TabsContent>
        </div>
      </Tabs>

      {/* Footer informatif */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5" />
            <div className="space-y-1">
              <p className="text-sm font-medium text-blue-900">
                Paramètres configurés pour le Cameroun
              </p>
              <p className="text-xs text-blue-700">
                Les valeurs par défaut sont optimisées pour les opérations au Cameroun (FCFA, +237). 
                Modifiez selon vos besoins spécifiques.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}