export const AUTH_CONFIG = {
  // Default credentials - change these in production
  USERNAME: 'admin',
  PASSWORD: 'microfinance2025',
  SESSION_DURATION: 24 * 60 * 60 * 1000, // 24 hours in milliseconds
  COOKIE_NAME: 'microfinance-session'
}