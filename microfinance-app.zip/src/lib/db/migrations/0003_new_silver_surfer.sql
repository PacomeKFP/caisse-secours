CREATE TABLE `app_config` (
	`id` text PRIMARY KEY NOT NULL,
	`category` text NOT NULL,
	`key` text NOT NULL,
	`value` text NOT NULL,
	`description` text,
	`type` text NOT NULL,
	`updated_at` text NOT NULL,
	`updated_by` text DEFAULT 'system' NOT NULL
);
