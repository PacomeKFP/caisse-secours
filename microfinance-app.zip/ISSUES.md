Error: Hydration failed because the server rendered HTML didn't match the client. As a result this tree will be regenerated on the client. This can happen if a SSR-ed Client Component used:

- A server/client branch `if (typeof window !== 'undefined')`.
- Variable input such as `Date.now()` or `Math.random()` which changes each time it's called.
- Date formatting in a user's locale which doesn't match the server.
- External changing data without sending a snapshot of it along with the HTML.
- Invalid HTML tag nesting.

It can also happen if the client has a browser extension installed which messes with the HTML before React loaded.

https://react.dev/link/hydration-mismatch

...
<HotReload assetPrefix="" globalError={[...]}>
<AppDevOverlayErrorBoundary globalError={[...]}>
<ReplaySsrOnlyErrors>
<DevRootHTTPAccessFallbackBoundary>
<HTTPAccessFallbackBoundary notFound={<NotAllowedRootHTTPFallbackError>}>
<HTTPAccessFallbackErrorBoundary pathname="/clients" notFound={<NotAllowedRootHTTPFallbackError>} ...>
<RedirectBoundary>
<RedirectErrorBoundary router={{...}}>
<Head headCacheNode={{lazyData:null, ...}}>
<__next_viewport_boundary__>
<meta>
<MetadataTree>
<__next_metadata_boundary__>
<__next_metadata_boundary__>
<div
+                           hidden={true}
-                           hidden={null}
-                           className="translate-tooltip-mtz translator-hidden"
                          >
+                           <Suspense fallback={null}>
-                           {"\n                    "}
                  ...

  at throwOnHydrationMismatch (http://localhost:3002/_next/static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js:2891:56)
  at updateSuspenseComponent (http://localhost:3002/_next/static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js:5654:99)
  at beginWork (http://localhost:3002/_next/static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js:6093:24)
  at runWithFiberInDEV (http://localhost:3002/_next/static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js:890:74)
  at performUnitOfWork (http://localhost:3002/_next/static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js:8236:97)
  at workLoopConcurrentByScheduler (http://localhost:3002/_next/static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js:8232:58)
  at renderRootConcurrent (http://localhost:3002/_next/static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js:8214:71)
  at performWorkOnRoot (http://localhost:3002/_next/static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js:7846:176)
  at performWorkOnRootViaSchedulerTask (http://localhost:3002/_next/static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc06._.js:8820:9)
  at MessagePort.performWorkUntilDeadline (http://localhost:3002/_next/static/chunks/node_modules_next_dist_compiled_0f1b9fd4._.js:2588:64)